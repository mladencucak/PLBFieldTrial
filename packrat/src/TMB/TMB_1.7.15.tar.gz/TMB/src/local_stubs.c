// Copyright (C) 2013-2015 Kasper Kristensen
// License: GPL-2

#include "Matrix_stubs.c"
