/* $Id$ */
# include "cppad/poly.hpp"
